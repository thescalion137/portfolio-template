import React from 'react';
import History from '../components/History/History';

export default function HistoryPage(props) {
  return <History data={props.data} />;
}
