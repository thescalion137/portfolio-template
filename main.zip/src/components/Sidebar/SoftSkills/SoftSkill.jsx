import React from 'react';

export default function SoftSkill(props) {
  return <li>{props.skills}</li>;
}